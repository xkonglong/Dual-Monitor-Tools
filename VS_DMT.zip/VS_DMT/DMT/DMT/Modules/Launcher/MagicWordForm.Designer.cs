﻿namespace DMT.Modules.Launcher
{
	partial class MagicWordForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MagicWordForm));
            this.buttonTest = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttonResetTimesUsed = new System.Windows.Forms.Button();
            this.labelTimesUsed = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.buttonResetLastUsed = new System.Windows.Forms.Button();
            this.labelLastUsed = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBoxIcon = new System.Windows.Forms.PictureBox();
            this.buttonDirBrowse = new System.Windows.Forms.Button();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.startupPositionControl1 = new DMT.Modules.Launcher.StartupPositionControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.startupPositionControl2 = new DMT.Modules.Launcher.StartupPositionControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.startupPositionControl3 = new DMT.Modules.Launcher.StartupPositionControl();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.startupPositionControl4 = new DMT.Modules.Launcher.StartupPositionControl();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.textBoxComment = new System.Windows.Forms.TextBox();
            this.textBoxCaption = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxWindowClass = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonBrowse = new System.Windows.Forms.Button();
            this.textBoxParameters = new System.Windows.Forms.TextBox();
            this.textBoxStartDirectory = new System.Windows.Forms.TextBox();
            this.textBoxFilename = new System.Windows.Forms.TextBox();
            this.textBoxAlias = new System.Windows.Forms.TextBox();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.buttonOK = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.windowPicker = new DMT.Library.GuiUtils.WindowPicker();
            this.buttonInternalCommand = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIcon)).BeginInit();
            this.tabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.windowPicker)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonTest
            // 
            this.buttonTest.Location = new System.Drawing.Point(379, 16);
            this.buttonTest.Name = "buttonTest";
            this.buttonTest.Size = new System.Drawing.Size(128, 21);
            this.buttonTest.TabIndex = 38;
            this.buttonTest.Text = "测试魔法单词";
            this.buttonTest.UseVisualStyleBackColor = true;
            this.buttonTest.Click += new System.EventHandler(this.buttonTest_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.buttonResetTimesUsed);
            this.groupBox2.Controls.Add(this.labelTimesUsed);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.buttonResetLastUsed);
            this.groupBox2.Controls.Add(this.labelLastUsed);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Location = new System.Drawing.Point(12, 338);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(683, 44);
            this.groupBox2.TabIndex = 39;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "状态";
            // 
            // buttonResetTimesUsed
            // 
            this.buttonResetTimesUsed.Location = new System.Drawing.Point(598, 14);
            this.buttonResetTimesUsed.Name = "buttonResetTimesUsed";
            this.buttonResetTimesUsed.Size = new System.Drawing.Size(75, 21);
            this.buttonResetTimesUsed.TabIndex = 5;
            this.buttonResetTimesUsed.Text = "重置";
            this.buttonResetTimesUsed.UseVisualStyleBackColor = true;
            this.buttonResetTimesUsed.Click += new System.EventHandler(this.buttonResetTimesUsed_Click);
            // 
            // labelTimesUsed
            // 
            this.labelTimesUsed.Location = new System.Drawing.Point(519, 18);
            this.labelTimesUsed.Name = "labelTimesUsed";
            this.labelTimesUsed.Size = new System.Drawing.Size(64, 12);
            this.labelTimesUsed.TabIndex = 4;
            this.labelTimesUsed.Text = "labelTimesUsed";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(447, 18);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 12);
            this.label9.TabIndex = 3;
            this.label9.Text = "已用时间:";
            // 
            // buttonResetLastUsed
            // 
            this.buttonResetLastUsed.Location = new System.Drawing.Point(220, 14);
            this.buttonResetLastUsed.Name = "buttonResetLastUsed";
            this.buttonResetLastUsed.Size = new System.Drawing.Size(75, 21);
            this.buttonResetLastUsed.TabIndex = 2;
            this.buttonResetLastUsed.Text = "重置";
            this.buttonResetLastUsed.UseVisualStyleBackColor = true;
            this.buttonResetLastUsed.Click += new System.EventHandler(this.buttonResetLastUsed_Click);
            // 
            // labelLastUsed
            // 
            this.labelLastUsed.Location = new System.Drawing.Point(80, 18);
            this.labelLastUsed.Name = "labelLastUsed";
            this.labelLastUsed.Size = new System.Drawing.Size(134, 12);
            this.labelLastUsed.TabIndex = 1;
            this.labelLastUsed.Text = "labelLastUsed";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(7, 18);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 12);
            this.label8.TabIndex = 0;
            this.label8.Text = "上次使用:";
            // 
            // pictureBoxIcon
            // 
            this.pictureBoxIcon.Location = new System.Drawing.Point(328, 11);
            this.pictureBoxIcon.Name = "pictureBoxIcon";
            this.pictureBoxIcon.Size = new System.Drawing.Size(32, 30);
            this.pictureBoxIcon.TabIndex = 37;
            this.pictureBoxIcon.TabStop = false;
            // 
            // buttonDirBrowse
            // 
            this.buttonDirBrowse.Location = new System.Drawing.Point(624, 68);
            this.buttonDirBrowse.Name = "buttonDirBrowse";
            this.buttonDirBrowse.Size = new System.Drawing.Size(75, 21);
            this.buttonDirBrowse.TabIndex = 36;
            this.buttonDirBrowse.Text = "浏览...";
            this.toolTip.SetToolTip(this.buttonDirBrowse, "Browse for the starting directory.");
            this.buttonDirBrowse.UseVisualStyleBackColor = true;
            this.buttonDirBrowse.Click += new System.EventHandler(this.buttonDirBrowse_Click);
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Controls.Add(this.tabPage3);
            this.tabControl.Controls.Add(this.tabPage4);
            this.tabControl.Location = new System.Drawing.Point(15, 222);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(684, 110);
            this.tabControl.TabIndex = 35;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.startupPositionControl1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(676, 84);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "启动位置1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // startupPositionControl1
            // 
            this.startupPositionControl1.Location = new System.Drawing.Point(6, 3);
            this.startupPositionControl1.Name = "startupPositionControl1";
            this.startupPositionControl1.Size = new System.Drawing.Size(667, 80);
            this.startupPositionControl1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.startupPositionControl2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(676, 84);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "启动位置2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // startupPositionControl2
            // 
            this.startupPositionControl2.Location = new System.Drawing.Point(6, 3);
            this.startupPositionControl2.Name = "startupPositionControl2";
            this.startupPositionControl2.Size = new System.Drawing.Size(667, 80);
            this.startupPositionControl2.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.startupPositionControl3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(676, 84);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "启动位置3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // startupPositionControl3
            // 
            this.startupPositionControl3.Location = new System.Drawing.Point(6, 3);
            this.startupPositionControl3.Name = "startupPositionControl3";
            this.startupPositionControl3.Size = new System.Drawing.Size(667, 80);
            this.startupPositionControl3.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.startupPositionControl4);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(676, 84);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "启动位置4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // startupPositionControl4
            // 
            this.startupPositionControl4.Location = new System.Drawing.Point(6, 3);
            this.startupPositionControl4.Name = "startupPositionControl4";
            this.startupPositionControl4.Size = new System.Drawing.Size(667, 80);
            this.startupPositionControl4.TabIndex = 0;
            // 
            // textBoxComment
            // 
            this.textBoxComment.Location = new System.Drawing.Point(108, 118);
            this.textBoxComment.Name = "textBoxComment";
            this.textBoxComment.Size = new System.Drawing.Size(510, 21);
            this.textBoxComment.TabIndex = 32;
            this.toolTip.SetToolTip(this.textBoxComment, "如果你愿意，你可以选择在这里注释。");
            // 
            // textBoxCaption
            // 
            this.textBoxCaption.Location = new System.Drawing.Point(93, 42);
            this.textBoxCaption.Name = "textBoxCaption";
            this.textBoxCaption.Size = new System.Drawing.Size(510, 21);
            this.textBoxCaption.TabIndex = 3;
            this.toolTip.SetToolTip(this.textBoxCaption, "正则表达式来帮助识别正确的窗口。\r\n通常情况下，你只需要从窗口标题中提取一个子串就可以了。");
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxCaption);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.textBoxWindowClass);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(15, 142);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(684, 75);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "应用窗口识别";
            this.toolTip.SetToolTip(this.groupBox1, "当应用程序窗口打开时，帮助识别它的字段。\r\n以便将其移动到正确的位置。\r\n这些只是有时需要，而且只有在您希望将其移动到正确的位置时才需要。\r\n应用程序窗口要在特定" +
        "位置打开。");
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 44);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 12);
            this.label6.TabIndex = 2;
            this.label6.Text = "标题:";
            // 
            // textBoxWindowClass
            // 
            this.textBoxWindowClass.Location = new System.Drawing.Point(93, 18);
            this.textBoxWindowClass.Name = "textBoxWindowClass";
            this.textBoxWindowClass.Size = new System.Drawing.Size(510, 21);
            this.textBoxWindowClass.TabIndex = 1;
            this.toolTip.SetToolTip(this.textBoxWindowClass, "这是上述程序使用的窗口类的名称。\r\n可以留空，但如果你使用十字线，就会填入。");
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "Window Class:";
            // 
            // buttonBrowse
            // 
            this.buttonBrowse.Location = new System.Drawing.Point(624, 44);
            this.buttonBrowse.Name = "buttonBrowse";
            this.buttonBrowse.Size = new System.Drawing.Size(75, 21);
            this.buttonBrowse.TabIndex = 29;
            this.buttonBrowse.Text = "浏览...";
            this.toolTip.SetToolTip(this.buttonBrowse, "Browse for the application or document.");
            this.buttonBrowse.UseVisualStyleBackColor = true;
            this.buttonBrowse.Click += new System.EventHandler(this.buttonBrowse_Click);
            // 
            // textBoxParameters
            // 
            this.textBoxParameters.Location = new System.Drawing.Point(108, 94);
            this.textBoxParameters.Name = "textBoxParameters";
            this.textBoxParameters.Size = new System.Drawing.Size(510, 21);
            this.textBoxParameters.TabIndex = 28;
            this.toolTip.SetToolTip(this.textBoxParameters, "任何需要传递给应用程序的参数。\r\n通常会留空。");
            // 
            // textBoxStartDirectory
            // 
            this.textBoxStartDirectory.Location = new System.Drawing.Point(108, 70);
            this.textBoxStartDirectory.Name = "textBoxStartDirectory";
            this.textBoxStartDirectory.Size = new System.Drawing.Size(510, 21);
            this.textBoxStartDirectory.TabIndex = 26;
            this.toolTip.SetToolTip(this.textBoxStartDirectory, "这是你希望应用程序启动的工作目录。\r\n通常会留空。");
            // 
            // textBoxFilename
            // 
            this.textBoxFilename.Location = new System.Drawing.Point(108, 46);
            this.textBoxFilename.Name = "textBoxFilename";
            this.textBoxFilename.Size = new System.Drawing.Size(510, 21);
            this.textBoxFilename.TabIndex = 24;
            this.toolTip.SetToolTip(this.textBoxFilename, "这可以是\r\n一个应用程序的完整路径。\r\n如果文件的扩展名与应用程序相关联，则文件的完整路径。\r\n你想在Windows资源管理器中打开的文件夹。\r\n或您希望在浏览器" +
        "中打开的网页地址。");
            // 
            // textBoxAlias
            // 
            this.textBoxAlias.Location = new System.Drawing.Point(108, 22);
            this.textBoxAlias.Name = "textBoxAlias";
            this.textBoxAlias.Size = new System.Drawing.Size(207, 21);
            this.textBoxAlias.TabIndex = 22;
            this.toolTip.SetToolTip(this.textBoxAlias, "这是您键入（或开始键入）运行该程序的单词。");
            // 
            // buttonCancel
            // 
            this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonCancel.Location = new System.Drawing.Point(406, 388);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(75, 21);
            this.buttonCancel.TabIndex = 34;
            this.buttonCancel.Text = "取消";
            this.buttonCancel.UseVisualStyleBackColor = true;
            // 
            // buttonOK
            // 
            this.buttonOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonOK.Location = new System.Drawing.Point(249, 388);
            this.buttonOK.Name = "buttonOK";
            this.buttonOK.Size = new System.Drawing.Size(75, 21);
            this.buttonOK.TabIndex = 33;
            this.buttonOK.Text = "确定";
            this.buttonOK.UseVisualStyleBackColor = true;
            this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 121);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 12);
            this.label7.TabIndex = 31;
            this.label7.Text = "注释:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 97);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 12);
            this.label4.TabIndex = 27;
            this.label4.Text = "参数:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 12);
            this.label3.TabIndex = 25;
            this.label3.Text = "启动位置:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 12);
            this.label2.TabIndex = 23;
            this.label2.Text = "文件名:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 12);
            this.label1.TabIndex = 21;
            this.label1.Text = "魔法单词:";
            // 
            // windowPicker
            // 
            this.windowPicker.Location = new System.Drawing.Point(637, 95);
            this.windowPicker.Name = "windowPicker";
            this.windowPicker.Size = new System.Drawing.Size(48, 44);
            this.windowPicker.TabIndex = 40;
            this.windowPicker.TabStop = false;
            // 
            // buttonInternalCommand
            // 
            this.buttonInternalCommand.Location = new System.Drawing.Point(567, 18);
            this.buttonInternalCommand.Name = "buttonInternalCommand";
            this.buttonInternalCommand.Size = new System.Drawing.Size(132, 21);
            this.buttonInternalCommand.TabIndex = 41;
            this.buttonInternalCommand.Text = "内部命令...";
            this.buttonInternalCommand.UseVisualStyleBackColor = true;
            this.buttonInternalCommand.Click += new System.EventHandler(this.buttonInternalCommand_Click);
            // 
            // MagicWordForm
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(711, 419);
            this.Controls.Add(this.buttonInternalCommand);
            this.Controls.Add(this.windowPicker);
            this.Controls.Add(this.buttonTest);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.pictureBoxIcon);
            this.Controls.Add(this.buttonDirBrowse);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonOK);
            this.Controls.Add(this.textBoxComment);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.buttonBrowse);
            this.Controls.Add(this.textBoxParameters);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxStartDirectory);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxFilename);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxAlias);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MagicWordForm";
            this.ShowInTaskbar = false;
            this.Text = "魔法单词";
            this.Load += new System.EventHandler(this.MagicWordForm_Load);
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.MagicWordForm_DragDrop);
            this.DragEnter += new System.Windows.Forms.DragEventHandler(this.MagicWordForm_DragEnter);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxIcon)).EndInit();
            this.tabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.windowPicker)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button buttonTest;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Button buttonResetTimesUsed;
		private System.Windows.Forms.Label labelTimesUsed;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Button buttonResetLastUsed;
		private System.Windows.Forms.Label labelLastUsed;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.PictureBox pictureBoxIcon;
		private System.Windows.Forms.Button buttonDirBrowse;
		private System.Windows.Forms.ToolTip toolTip;
		private System.Windows.Forms.TabControl tabControl;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.TabPage tabPage3;
		private System.Windows.Forms.TabPage tabPage4;
		private System.Windows.Forms.TextBox textBoxComment;
		private System.Windows.Forms.TextBox textBoxCaption;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox textBoxWindowClass;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Button buttonBrowse;
		private System.Windows.Forms.TextBox textBoxParameters;
		private System.Windows.Forms.TextBox textBoxStartDirectory;
		private System.Windows.Forms.TextBox textBoxFilename;
		private System.Windows.Forms.TextBox textBoxAlias;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.Button buttonOK;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private Library.GuiUtils.WindowPicker windowPicker;
		private StartupPositionControl startupPositionControl1;
		private StartupPositionControl startupPositionControl2;
		private StartupPositionControl startupPositionControl3;
		private StartupPositionControl startupPositionControl4;
		private System.Windows.Forms.Button buttonInternalCommand;
	}
}