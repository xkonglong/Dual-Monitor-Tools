﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("DualWallpaper 中文版")]
[assembly: AssemblyDescription("本程序适用于多显示器设置的用户. \r\n\r\n它允许您在每个显示器上创建不同图像的壁纸，或将单个图像分布在多个显示器上，或这些图像的组合。")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("GNE")]
[assembly: AssemblyProduct("DualWallpaper 中文版")]
[assembly: AssemblyCopyright("Copyright © 2010-2018 Gerald Evans and contributors && 小恐龙工作室")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("dce7b634-84f0-422b-99b9-bc2419182f7b")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("2.8.0.0")]
[assembly: AssemblyFileVersion("2.8.0.0")]
