﻿namespace DMT.Modules.SwapScreen
{
	partial class ScrollableUdasPanel
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.udaPanel0 = new DMT.Modules.SwapScreen.UdaPanel();
			this.vScrollBar = new System.Windows.Forms.VScrollBar();
			this.udaPanel1 = new DMT.Modules.SwapScreen.UdaPanel();
			this.udaPanel2 = new DMT.Modules.SwapScreen.UdaPanel();
			this.udaPanel3 = new DMT.Modules.SwapScreen.UdaPanel();
			this.udaPanel4 = new DMT.Modules.SwapScreen.UdaPanel();
			this.udaPanel5 = new DMT.Modules.SwapScreen.UdaPanel();
			this.udaPanel6 = new DMT.Modules.SwapScreen.UdaPanel();
			this.udaPanel7 = new DMT.Modules.SwapScreen.UdaPanel();
			this.udaPanel8 = new DMT.Modules.SwapScreen.UdaPanel();
			this.udaPanel9 = new DMT.Modules.SwapScreen.UdaPanel();
			this.SuspendLayout();
			// 
			// udaPanel0
			// 
			this.udaPanel0.Location = new System.Drawing.Point(0, 0);
			this.udaPanel0.Name = "udaPanel0";
			this.udaPanel0.Size = new System.Drawing.Size(465, 23);
			this.udaPanel0.TabIndex = 0;
			// 
			// vScrollBar
			// 
			this.vScrollBar.LargeChange = 3;
			this.vScrollBar.Location = new System.Drawing.Point(468, 0);
			this.vScrollBar.Name = "vScrollBar";
			this.vScrollBar.Size = new System.Drawing.Size(17, 283);
			this.vScrollBar.TabIndex = 11;
			this.vScrollBar.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vScrollBar_Scroll);
			// 
			// udaPanel1
			// 
			this.udaPanel1.Location = new System.Drawing.Point(0, 29);
			this.udaPanel1.Name = "udaPanel1";
			this.udaPanel1.Size = new System.Drawing.Size(465, 23);
			this.udaPanel1.TabIndex = 12;
			// 
			// udaPanel2
			// 
			this.udaPanel2.Location = new System.Drawing.Point(0, 58);
			this.udaPanel2.Name = "udaPanel2";
			this.udaPanel2.Size = new System.Drawing.Size(465, 23);
			this.udaPanel2.TabIndex = 13;
			// 
			// udaPanel3
			// 
			this.udaPanel3.Location = new System.Drawing.Point(0, 87);
			this.udaPanel3.Name = "udaPanel3";
			this.udaPanel3.Size = new System.Drawing.Size(465, 23);
			this.udaPanel3.TabIndex = 14;
			// 
			// udaPanel4
			// 
			this.udaPanel4.Location = new System.Drawing.Point(0, 116);
			this.udaPanel4.Name = "udaPanel4";
			this.udaPanel4.Size = new System.Drawing.Size(465, 23);
			this.udaPanel4.TabIndex = 15;
			// 
			// udaPanel5
			// 
			this.udaPanel5.Location = new System.Drawing.Point(0, 145);
			this.udaPanel5.Name = "udaPanel5";
			this.udaPanel5.Size = new System.Drawing.Size(465, 23);
			this.udaPanel5.TabIndex = 16;
			// 
			// udaPanel6
			// 
			this.udaPanel6.Location = new System.Drawing.Point(0, 174);
			this.udaPanel6.Name = "udaPanel6";
			this.udaPanel6.Size = new System.Drawing.Size(465, 23);
			this.udaPanel6.TabIndex = 17;
			// 
			// udaPanel7
			// 
			this.udaPanel7.Location = new System.Drawing.Point(0, 203);
			this.udaPanel7.Name = "udaPanel7";
			this.udaPanel7.Size = new System.Drawing.Size(465, 23);
			this.udaPanel7.TabIndex = 18;
			// 
			// udaPanel8
			// 
			this.udaPanel8.Location = new System.Drawing.Point(0, 232);
			this.udaPanel8.Name = "udaPanel8";
			this.udaPanel8.Size = new System.Drawing.Size(465, 23);
			this.udaPanel8.TabIndex = 19;
			// 
			// udaPanel9
			// 
			this.udaPanel9.Location = new System.Drawing.Point(0, 261);
			this.udaPanel9.Name = "udaPanel9";
			this.udaPanel9.Size = new System.Drawing.Size(465, 23);
			this.udaPanel9.TabIndex = 20;
			// 
			// ScrollableUdasPanel
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.udaPanel9);
			this.Controls.Add(this.udaPanel8);
			this.Controls.Add(this.udaPanel7);
			this.Controls.Add(this.udaPanel6);
			this.Controls.Add(this.udaPanel5);
			this.Controls.Add(this.udaPanel4);
			this.Controls.Add(this.udaPanel3);
			this.Controls.Add(this.udaPanel2);
			this.Controls.Add(this.udaPanel1);
			this.Controls.Add(this.vScrollBar);
			this.Controls.Add(this.udaPanel0);
			this.Name = "ScrollableUdasPanel";
			this.Size = new System.Drawing.Size(488, 286);
			this.ResumeLayout(false);

		}

		#endregion

		private UdaPanel udaPanel0;
		private System.Windows.Forms.VScrollBar vScrollBar;
		private UdaPanel udaPanel1;
		private UdaPanel udaPanel2;
		private UdaPanel udaPanel3;
		private UdaPanel udaPanel4;
		private UdaPanel udaPanel5;
		private UdaPanel udaPanel6;
		private UdaPanel udaPanel7;
		private UdaPanel udaPanel8;
		private UdaPanel udaPanel9;
	}
}
