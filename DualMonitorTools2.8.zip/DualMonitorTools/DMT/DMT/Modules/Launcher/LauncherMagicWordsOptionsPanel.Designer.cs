﻿namespace DMT.Modules.Launcher
{
	partial class LauncherMagicWordsOptionsPanel
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.buttonResetCounts = new System.Windows.Forms.Button();
            this.buttonDelete = new System.Windows.Forms.Button();
            this.buttonEdit = new System.Windows.Forms.Button();
            this.buttonAdd = new System.Windows.Forms.Button();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.magicWordsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.aliasDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.filenameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Parameters = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Comment = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UseCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LastUsed = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aliasDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.filenameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.parametersDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startDirectoryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.commentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.windowClassDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.captionRegExprDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.useCountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lastUsedDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startupPosition1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startupPosition2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startupPosition3DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.startupPosition4DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.magicWordsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonResetCounts
            // 
            this.buttonResetCounts.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonResetCounts.Location = new System.Drawing.Point(369, 305);
            this.buttonResetCounts.Name = "buttonResetCounts";
            this.buttonResetCounts.Size = new System.Drawing.Size(124, 21);
            this.buttonResetCounts.TabIndex = 9;
            this.buttonResetCounts.Text = "重置使用次数";
            this.buttonResetCounts.UseVisualStyleBackColor = true;
            this.buttonResetCounts.Click += new System.EventHandler(this.buttonResetCounts_Click);
            // 
            // buttonDelete
            // 
            this.buttonDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonDelete.Location = new System.Drawing.Point(168, 305);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(75, 21);
            this.buttonDelete.TabIndex = 8;
            this.buttonDelete.Text = "删除(&D)";
            this.buttonDelete.UseVisualStyleBackColor = true;
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // buttonEdit
            // 
            this.buttonEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonEdit.Location = new System.Drawing.Point(86, 305);
            this.buttonEdit.Name = "buttonEdit";
            this.buttonEdit.Size = new System.Drawing.Size(75, 21);
            this.buttonEdit.TabIndex = 7;
            this.buttonEdit.Text = "编辑(&E)";
            this.buttonEdit.UseVisualStyleBackColor = true;
            this.buttonEdit.Click += new System.EventHandler(this.buttonEdit_Click);
            // 
            // buttonAdd
            // 
            this.buttonAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonAdd.Location = new System.Drawing.Point(4, 305);
            this.buttonAdd.Name = "buttonAdd";
            this.buttonAdd.Size = new System.Drawing.Size(75, 21);
            this.buttonAdd.TabIndex = 6;
            this.buttonAdd.Text = "添加(&A)";
            this.buttonAdd.UseVisualStyleBackColor = true;
            this.buttonAdd.Click += new System.EventHandler(this.buttonAdd_Click);
            // 
            // dataGridView
            // 
            this.dataGridView.AllowUserToAddRows = false;
            this.dataGridView.AllowUserToDeleteRows = false;
            this.dataGridView.AllowUserToResizeColumns = false;
            this.dataGridView.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView.AutoGenerateColumns = false;
            this.dataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.aliasDataGridViewTextBoxColumn,
            this.filenameDataGridViewTextBoxColumn,
            this.Parameters,
            this.Comment,
            this.UseCount,
            this.LastUsed,
            this.aliasDataGridViewTextBoxColumn1,
            this.filenameDataGridViewTextBoxColumn1,
            this.parametersDataGridViewTextBoxColumn,
            this.startDirectoryDataGridViewTextBoxColumn,
            this.commentDataGridViewTextBoxColumn,
            this.windowClassDataGridViewTextBoxColumn,
            this.captionRegExprDataGridViewTextBoxColumn,
            this.useCountDataGridViewTextBoxColumn,
            this.lastUsedDataGridViewTextBoxColumn,
            this.startupPosition1DataGridViewTextBoxColumn,
            this.startupPosition2DataGridViewTextBoxColumn,
            this.startupPosition3DataGridViewTextBoxColumn,
            this.startupPosition4DataGridViewTextBoxColumn});
            this.dataGridView.DataSource = this.magicWordsBindingSource;
            this.dataGridView.Location = new System.Drawing.Point(6, 0);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.ReadOnly = true;
            this.dataGridView.RowHeadersVisible = false;
            this.dataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView.Size = new System.Drawing.Size(487, 299);
            this.dataGridView.TabIndex = 5;
            this.dataGridView.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_CellDoubleClick);
            this.dataGridView.SelectionChanged += new System.EventHandler(this.dataGridView_SelectionChanged);
            this.dataGridView.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dataGridView_KeyPress);
            // 
            // magicWordsBindingSource
            // 
            this.magicWordsBindingSource.DataSource = typeof(DMT.Modules.Launcher.MagicWords);
            // 
            // aliasDataGridViewTextBoxColumn
            // 
            this.aliasDataGridViewTextBoxColumn.DataPropertyName = "Alias";
            this.aliasDataGridViewTextBoxColumn.Frozen = true;
            this.aliasDataGridViewTextBoxColumn.HeaderText = "魔法单词";
            this.aliasDataGridViewTextBoxColumn.Name = "aliasDataGridViewTextBoxColumn";
            this.aliasDataGridViewTextBoxColumn.ReadOnly = true;
            this.aliasDataGridViewTextBoxColumn.Width = 78;
            // 
            // filenameDataGridViewTextBoxColumn
            // 
            this.filenameDataGridViewTextBoxColumn.DataPropertyName = "Filename";
            this.filenameDataGridViewTextBoxColumn.HeaderText = "文件名";
            this.filenameDataGridViewTextBoxColumn.Name = "filenameDataGridViewTextBoxColumn";
            this.filenameDataGridViewTextBoxColumn.ReadOnly = true;
            this.filenameDataGridViewTextBoxColumn.Width = 66;
            // 
            // Parameters
            // 
            this.Parameters.DataPropertyName = "Parameters";
            this.Parameters.HeaderText = "参数";
            this.Parameters.Name = "Parameters";
            this.Parameters.ReadOnly = true;
            this.Parameters.Width = 54;
            // 
            // Comment
            // 
            this.Comment.DataPropertyName = "Comment";
            this.Comment.HeaderText = "注释";
            this.Comment.Name = "Comment";
            this.Comment.ReadOnly = true;
            this.Comment.Width = 54;
            // 
            // UseCount
            // 
            this.UseCount.DataPropertyName = "UseCount";
            this.UseCount.HeaderText = "使用次数";
            this.UseCount.Name = "UseCount";
            this.UseCount.ReadOnly = true;
            this.UseCount.Width = 78;
            // 
            // LastUsed
            // 
            this.LastUsed.DataPropertyName = "LastUsed";
            this.LastUsed.HeaderText = "上次使用";
            this.LastUsed.Name = "LastUsed";
            this.LastUsed.ReadOnly = true;
            this.LastUsed.Width = 78;
            // 
            // aliasDataGridViewTextBoxColumn1
            // 
            this.aliasDataGridViewTextBoxColumn1.DataPropertyName = "Alias";
            this.aliasDataGridViewTextBoxColumn1.HeaderText = "别名";
            this.aliasDataGridViewTextBoxColumn1.Name = "aliasDataGridViewTextBoxColumn1";
            this.aliasDataGridViewTextBoxColumn1.ReadOnly = true;
            this.aliasDataGridViewTextBoxColumn1.Width = 54;
            // 
            // filenameDataGridViewTextBoxColumn1
            // 
            this.filenameDataGridViewTextBoxColumn1.DataPropertyName = "Filename";
            this.filenameDataGridViewTextBoxColumn1.HeaderText = "文件名";
            this.filenameDataGridViewTextBoxColumn1.Name = "filenameDataGridViewTextBoxColumn1";
            this.filenameDataGridViewTextBoxColumn1.ReadOnly = true;
            this.filenameDataGridViewTextBoxColumn1.Width = 66;
            // 
            // parametersDataGridViewTextBoxColumn
            // 
            this.parametersDataGridViewTextBoxColumn.DataPropertyName = "Parameters";
            this.parametersDataGridViewTextBoxColumn.HeaderText = "参数";
            this.parametersDataGridViewTextBoxColumn.Name = "parametersDataGridViewTextBoxColumn";
            this.parametersDataGridViewTextBoxColumn.ReadOnly = true;
            this.parametersDataGridViewTextBoxColumn.Width = 54;
            // 
            // startDirectoryDataGridViewTextBoxColumn
            // 
            this.startDirectoryDataGridViewTextBoxColumn.DataPropertyName = "StartDirectory";
            this.startDirectoryDataGridViewTextBoxColumn.HeaderText = "启动文件夹";
            this.startDirectoryDataGridViewTextBoxColumn.Name = "startDirectoryDataGridViewTextBoxColumn";
            this.startDirectoryDataGridViewTextBoxColumn.ReadOnly = true;
            this.startDirectoryDataGridViewTextBoxColumn.Width = 90;
            // 
            // commentDataGridViewTextBoxColumn
            // 
            this.commentDataGridViewTextBoxColumn.DataPropertyName = "Comment";
            this.commentDataGridViewTextBoxColumn.HeaderText = "注释";
            this.commentDataGridViewTextBoxColumn.Name = "commentDataGridViewTextBoxColumn";
            this.commentDataGridViewTextBoxColumn.ReadOnly = true;
            this.commentDataGridViewTextBoxColumn.Width = 54;
            // 
            // windowClassDataGridViewTextBoxColumn
            // 
            this.windowClassDataGridViewTextBoxColumn.DataPropertyName = "WindowClass";
            this.windowClassDataGridViewTextBoxColumn.HeaderText = "WindowClass";
            this.windowClassDataGridViewTextBoxColumn.Name = "windowClassDataGridViewTextBoxColumn";
            this.windowClassDataGridViewTextBoxColumn.ReadOnly = true;
            this.windowClassDataGridViewTextBoxColumn.Width = 96;
            // 
            // captionRegExprDataGridViewTextBoxColumn
            // 
            this.captionRegExprDataGridViewTextBoxColumn.DataPropertyName = "CaptionRegExpr";
            this.captionRegExprDataGridViewTextBoxColumn.HeaderText = "标题正则表达式";
            this.captionRegExprDataGridViewTextBoxColumn.Name = "captionRegExprDataGridViewTextBoxColumn";
            this.captionRegExprDataGridViewTextBoxColumn.ReadOnly = true;
            this.captionRegExprDataGridViewTextBoxColumn.Width = 83;
            // 
            // useCountDataGridViewTextBoxColumn
            // 
            this.useCountDataGridViewTextBoxColumn.DataPropertyName = "UseCount";
            this.useCountDataGridViewTextBoxColumn.HeaderText = "使用次数";
            this.useCountDataGridViewTextBoxColumn.Name = "useCountDataGridViewTextBoxColumn";
            this.useCountDataGridViewTextBoxColumn.ReadOnly = true;
            this.useCountDataGridViewTextBoxColumn.Width = 61;
            // 
            // lastUsedDataGridViewTextBoxColumn
            // 
            this.lastUsedDataGridViewTextBoxColumn.DataPropertyName = "LastUsed";
            this.lastUsedDataGridViewTextBoxColumn.HeaderText = "上次使用";
            this.lastUsedDataGridViewTextBoxColumn.Name = "lastUsedDataGridViewTextBoxColumn";
            this.lastUsedDataGridViewTextBoxColumn.ReadOnly = true;
            this.lastUsedDataGridViewTextBoxColumn.Width = 61;
            // 
            // startupPosition1DataGridViewTextBoxColumn
            // 
            this.startupPosition1DataGridViewTextBoxColumn.DataPropertyName = "StartupPosition1";
            this.startupPosition1DataGridViewTextBoxColumn.HeaderText = "启动位置1";
            this.startupPosition1DataGridViewTextBoxColumn.Name = "startupPosition1DataGridViewTextBoxColumn";
            this.startupPosition1DataGridViewTextBoxColumn.ReadOnly = true;
            this.startupPosition1DataGridViewTextBoxColumn.Width = 61;
            // 
            // startupPosition2DataGridViewTextBoxColumn
            // 
            this.startupPosition2DataGridViewTextBoxColumn.DataPropertyName = "StartupPosition2";
            this.startupPosition2DataGridViewTextBoxColumn.HeaderText = "启动位置2";
            this.startupPosition2DataGridViewTextBoxColumn.Name = "startupPosition2DataGridViewTextBoxColumn";
            this.startupPosition2DataGridViewTextBoxColumn.ReadOnly = true;
            this.startupPosition2DataGridViewTextBoxColumn.Width = 61;
            // 
            // startupPosition3DataGridViewTextBoxColumn
            // 
            this.startupPosition3DataGridViewTextBoxColumn.DataPropertyName = "StartupPosition3";
            this.startupPosition3DataGridViewTextBoxColumn.HeaderText = "启动位置3";
            this.startupPosition3DataGridViewTextBoxColumn.Name = "startupPosition3DataGridViewTextBoxColumn";
            this.startupPosition3DataGridViewTextBoxColumn.ReadOnly = true;
            this.startupPosition3DataGridViewTextBoxColumn.Width = 61;
            // 
            // startupPosition4DataGridViewTextBoxColumn
            // 
            this.startupPosition4DataGridViewTextBoxColumn.DataPropertyName = "StartupPosition4";
            this.startupPosition4DataGridViewTextBoxColumn.HeaderText = "启动位置4";
            this.startupPosition4DataGridViewTextBoxColumn.Name = "startupPosition4DataGridViewTextBoxColumn";
            this.startupPosition4DataGridViewTextBoxColumn.ReadOnly = true;
            this.startupPosition4DataGridViewTextBoxColumn.Width = 61;
            // 
            // LauncherMagicWordsOptionsPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.buttonResetCounts);
            this.Controls.Add(this.buttonDelete);
            this.Controls.Add(this.buttonEdit);
            this.Controls.Add(this.buttonAdd);
            this.Controls.Add(this.dataGridView);
            this.Name = "LauncherMagicWordsOptionsPanel";
            this.Size = new System.Drawing.Size(500, 332);
            this.Load += new System.EventHandler(this.LauncherMagicWordsOptionsPanel_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.magicWordsBindingSource)).EndInit();
            this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Button buttonResetCounts;
		private System.Windows.Forms.Button buttonDelete;
		private System.Windows.Forms.Button buttonEdit;
		private System.Windows.Forms.Button buttonAdd;
		private System.Windows.Forms.DataGridView dataGridView;
		private System.Windows.Forms.BindingSource magicWordsBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn aliasDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn filenameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Parameters;
        private System.Windows.Forms.DataGridViewTextBoxColumn Comment;
        private System.Windows.Forms.DataGridViewTextBoxColumn UseCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn LastUsed;
        private System.Windows.Forms.DataGridViewTextBoxColumn aliasDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn filenameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn parametersDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startDirectoryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn commentDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn windowClassDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn captionRegExprDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn useCountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastUsedDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startupPosition1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startupPosition2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startupPosition3DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startupPosition4DataGridViewTextBoxColumn;
    }
}
