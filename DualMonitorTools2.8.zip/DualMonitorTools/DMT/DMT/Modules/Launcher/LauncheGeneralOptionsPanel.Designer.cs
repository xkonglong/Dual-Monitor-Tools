﻿namespace DMT.Modules.Launcher
{
	partial class LauncheGeneralOptionsPanel
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.label6 = new System.Windows.Forms.Label();
            this.numericUpDownTimeout = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.radioButtonIconDetails = new System.Windows.Forms.RadioButton();
            this.radioButtonIconList = new System.Windows.Forms.RadioButton();
            this.radioButtonIconLargeIcon = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.numericUpDownIcons = new System.Windows.Forms.NumericUpDown();
            this.checkBoxMru = new System.Windows.Forms.CheckBox();
            this.checkBoxLoadWordsOnStartup = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTimeout)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownIcons)).BeginInit();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(291, 194);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(17, 12);
            this.label6.TabIndex = 14;
            this.label6.Text = "秒";
            // 
            // numericUpDownTimeout
            // 
            this.numericUpDownTimeout.Location = new System.Drawing.Point(221, 192);
            this.numericUpDownTimeout.Maximum = new decimal(new int[] {
            3600,
            0,
            0,
            0});
            this.numericUpDownTimeout.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownTimeout.Name = "numericUpDownTimeout";
            this.numericUpDownTimeout.Size = new System.Drawing.Size(64, 21);
            this.numericUpDownTimeout.TabIndex = 13;
            this.numericUpDownTimeout.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownTimeout.ValueChanged += new System.EventHandler(this.numericUpDownTimeout_ValueChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 194);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(131, 12);
            this.label5.TabIndex = 12;
            this.label5.Text = "应用程序窗口显示超时:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.radioButtonIconDetails);
            this.groupBox5.Controls.Add(this.radioButtonIconList);
            this.groupBox5.Controls.Add(this.radioButtonIconLargeIcon);
            this.groupBox5.Location = new System.Drawing.Point(10, 95);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(163, 92);
            this.groupBox5.TabIndex = 11;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "图标显示在:";
            // 
            // radioButtonIconDetails
            // 
            this.radioButtonIconDetails.AutoSize = true;
            this.radioButtonIconDetails.Location = new System.Drawing.Point(11, 62);
            this.radioButtonIconDetails.Name = "radioButtonIconDetails";
            this.radioButtonIconDetails.Size = new System.Drawing.Size(47, 16);
            this.radioButtonIconDetails.TabIndex = 2;
            this.radioButtonIconDetails.TabStop = true;
            this.radioButtonIconDetails.Text = "列表";
            this.radioButtonIconDetails.UseVisualStyleBackColor = true;
            this.radioButtonIconDetails.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
            // 
            // radioButtonIconList
            // 
            this.radioButtonIconList.AutoSize = true;
            this.radioButtonIconList.Location = new System.Drawing.Point(11, 41);
            this.radioButtonIconList.Name = "radioButtonIconList";
            this.radioButtonIconList.Size = new System.Drawing.Size(47, 16);
            this.radioButtonIconList.TabIndex = 1;
            this.radioButtonIconList.TabStop = true;
            this.radioButtonIconList.Text = "多列";
            this.radioButtonIconList.UseVisualStyleBackColor = true;
            this.radioButtonIconList.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
            // 
            // radioButtonIconLargeIcon
            // 
            this.radioButtonIconLargeIcon.AutoSize = true;
            this.radioButtonIconLargeIcon.Location = new System.Drawing.Point(11, 18);
            this.radioButtonIconLargeIcon.Name = "radioButtonIconLargeIcon";
            this.radioButtonIconLargeIcon.Size = new System.Drawing.Size(47, 16);
            this.radioButtonIconLargeIcon.TabIndex = 0;
            this.radioButtonIconLargeIcon.TabStop = true;
            this.radioButtonIconLargeIcon.Text = "网格";
            this.radioButtonIconLargeIcon.UseVisualStyleBackColor = true;
            this.radioButtonIconLargeIcon.CheckedChanged += new System.EventHandler(this.radioButton_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 12);
            this.label3.TabIndex = 10;
            this.label3.Text = "要显示的图标最大数量:";
            // 
            // numericUpDownIcons
            // 
            this.numericUpDownIcons.Location = new System.Drawing.Point(203, 71);
            this.numericUpDownIcons.Name = "numericUpDownIcons";
            this.numericUpDownIcons.Size = new System.Drawing.Size(54, 21);
            this.numericUpDownIcons.TabIndex = 9;
            this.numericUpDownIcons.ValueChanged += new System.EventHandler(this.numericUpDownIcons_ValueChanged);
            // 
            // checkBoxMru
            // 
            this.checkBoxMru.AutoSize = true;
            this.checkBoxMru.Location = new System.Drawing.Point(14, 8);
            this.checkBoxMru.Name = "checkBoxMru";
            this.checkBoxMru.Size = new System.Drawing.Size(276, 16);
            this.checkBoxMru.TabIndex = 8;
            this.checkBoxMru.Text = "在自动完成中使用最近使用的(而不是最常用的)";
            this.checkBoxMru.UseVisualStyleBackColor = true;
            this.checkBoxMru.CheckedChanged += new System.EventHandler(this.checkBoxMru_CheckedChanged);
            // 
            // checkBoxLoadWordsOnStartup
            // 
            this.checkBoxLoadWordsOnStartup.AutoSize = true;
            this.checkBoxLoadWordsOnStartup.Location = new System.Drawing.Point(14, 30);
            this.checkBoxLoadWordsOnStartup.Name = "checkBoxLoadWordsOnStartup";
            this.checkBoxLoadWordsOnStartup.Size = new System.Drawing.Size(132, 16);
            this.checkBoxLoadWordsOnStartup.TabIndex = 15;
            this.checkBoxLoadWordsOnStartup.Text = "启动时载入魔法单词";
            this.checkBoxLoadWordsOnStartup.UseVisualStyleBackColor = true;
            this.checkBoxLoadWordsOnStartup.CheckedChanged += new System.EventHandler(this.checkBoxLoadWordsOnStartup_CheckedChanged);
            // 
            // LauncheGeneralOptionsPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.checkBoxLoadWordsOnStartup);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.numericUpDownTimeout);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.numericUpDownIcons);
            this.Controls.Add(this.checkBoxMru);
            this.Name = "LauncheGeneralOptionsPanel";
            this.Size = new System.Drawing.Size(500, 332);
            this.Load += new System.EventHandler(this.LauncherImportOptionsPanel_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTimeout)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownIcons)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.NumericUpDown numericUpDownTimeout;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.GroupBox groupBox5;
		private System.Windows.Forms.RadioButton radioButtonIconDetails;
		private System.Windows.Forms.RadioButton radioButtonIconList;
		private System.Windows.Forms.RadioButton radioButtonIconLargeIcon;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.NumericUpDown numericUpDownIcons;
		private System.Windows.Forms.CheckBox checkBoxMru;
		private System.Windows.Forms.CheckBox checkBoxLoadWordsOnStartup;
	}
}
