﻿namespace DMT.Modules.Cursor
{
	partial class CursorDeadSpaceOptionsPanel
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CursorDeadSpaceOptionsPanel));
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.checkBoxDeadSpaceXJump = new System.Windows.Forms.CheckBox();
            this.checkBoxDeadSpaceYJump = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "死角光标跳跃";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(3, 164);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(494, 33);
            this.label3.TabIndex = 2;
            this.label3.Text = "这些选项允许你在这样的边界上移动光标，光标将跳到它移动方向上相邻最近的有效位置。";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(3, 198);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(455, 34);
            this.label4.TabIndex = 3;
            this.label4.Text = "注意：你通常只会勾选一项，而且只有非矩形的屏幕布局时才会勾选。";
            // 
            // checkBoxDeadSpaceXJump
            // 
            this.checkBoxDeadSpaceXJump.AutoSize = true;
            this.checkBoxDeadSpaceXJump.Location = new System.Drawing.Point(6, 243);
            this.checkBoxDeadSpaceXJump.Name = "checkBoxDeadSpaceXJump";
            this.checkBoxDeadSpaceXJump.Size = new System.Drawing.Size(204, 16);
            this.checkBoxDeadSpaceXJump.TabIndex = 4;
            this.checkBoxDeadSpaceXJump.Text = "允许光标在水平移动时跳过死角。";
            this.checkBoxDeadSpaceXJump.UseVisualStyleBackColor = true;
            this.checkBoxDeadSpaceXJump.CheckedChanged += new System.EventHandler(this.checkBoxDeadSpaceXJump_CheckedChanged);
            // 
            // checkBoxDeadSpaceYJump
            // 
            this.checkBoxDeadSpaceYJump.AutoSize = true;
            this.checkBoxDeadSpaceYJump.Location = new System.Drawing.Point(6, 264);
            this.checkBoxDeadSpaceYJump.Name = "checkBoxDeadSpaceYJump";
            this.checkBoxDeadSpaceYJump.Size = new System.Drawing.Size(204, 16);
            this.checkBoxDeadSpaceYJump.TabIndex = 5;
            this.checkBoxDeadSpaceYJump.Text = "允许光标在垂直移动时跳过死角。";
            this.checkBoxDeadSpaceYJump.UseVisualStyleBackColor = true;
            this.checkBoxDeadSpaceYJump.CheckedChanged += new System.EventHandler(this.checkBoxDeadSpaceYJump_CheckedChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(8, 66);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(134, 83);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(3, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(483, 30);
            this.label2.TabIndex = 7;
            this.label2.Text = "如果你有一个非矩形的屏幕布局，那么如果另一边没有显示器，你将无法跨越边界移动光标。";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(166, 73);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(320, 71);
            this.label5.TabIndex = 8;
            this.label5.Text = "如果你的显示器布局类似左图示例，那么当你的光标在右边的显示器上，你将无法通过红色区域向左移动光标。 这使得光标很容易被卡在显示器上，尤其是你看不到显示器时，就会造" +
    "成更大问题。";
            // 
            // CursorDeadSpaceOptionsPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.checkBoxDeadSpaceYJump);
            this.Controls.Add(this.checkBoxDeadSpaceXJump);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Name = "CursorDeadSpaceOptionsPanel";
            this.Size = new System.Drawing.Size(500, 332);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.CheckBox checkBoxDeadSpaceXJump;
		private System.Windows.Forms.CheckBox checkBoxDeadSpaceYJump;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label5;
	}
}
