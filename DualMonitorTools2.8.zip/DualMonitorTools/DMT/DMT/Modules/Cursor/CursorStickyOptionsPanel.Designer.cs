﻿namespace DMT.Modules.Cursor
{
	partial class CursorStickyOptionsPanel
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.comboBoxFreeMovementKey = new System.Windows.Forms.ComboBox();
            this.checkBoxPrimaryReturnUnhindered = new System.Windows.Forms.CheckBox();
            this.comboBoxCursorMode = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.checkBoxControlUnhindersCursor = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.scrollBarSticky = new System.Windows.Forms.HScrollBar();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.hotKeyPanelLockCursor = new DMT.Library.HotKeys.HotKeyPanel();
            this.hotKeyPanelStickyCursor = new DMT.Library.HotKeys.HotKeyPanel();
            this.hotKeyPanelFreeCursor = new DMT.Library.HotKeys.HotKeyPanel();
            this.checkBoxAllowButton = new System.Windows.Forms.CheckBox();
            this.comboBoxFreeMovementButton = new System.Windows.Forms.ComboBox();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // comboBoxFreeMovementKey
            // 
            this.comboBoxFreeMovementKey.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxFreeMovementKey.FormattingEnabled = true;
            this.comboBoxFreeMovementKey.Location = new System.Drawing.Point(279, 168);
            this.comboBoxFreeMovementKey.Name = "comboBoxFreeMovementKey";
            this.comboBoxFreeMovementKey.Size = new System.Drawing.Size(194, 20);
            this.comboBoxFreeMovementKey.TabIndex = 52;
            this.comboBoxFreeMovementKey.SelectedIndexChanged += new System.EventHandler(this.comboBoxFreeMovementKey_SelectedIndexChanged);
            // 
            // checkBoxPrimaryReturnUnhindered
            // 
            this.checkBoxPrimaryReturnUnhindered.AutoSize = true;
            this.checkBoxPrimaryReturnUnhindered.Location = new System.Drawing.Point(10, 214);
            this.checkBoxPrimaryReturnUnhindered.Name = "checkBoxPrimaryReturnUnhindered";
            this.checkBoxPrimaryReturnUnhindered.Size = new System.Drawing.Size(156, 16);
            this.checkBoxPrimaryReturnUnhindered.TabIndex = 51;
            this.checkBoxPrimaryReturnUnhindered.Text = "允许光标自由返回主屏幕";
            this.checkBoxPrimaryReturnUnhindered.UseVisualStyleBackColor = true;
            this.checkBoxPrimaryReturnUnhindered.CheckedChanged += new System.EventHandler(this.checkBoxPrimaryReturnUnhindered_CheckedChanged);
            // 
            // comboBoxCursorMode
            // 
            this.comboBoxCursorMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCursorMode.FormattingEnabled = true;
            this.comboBoxCursorMode.Location = new System.Drawing.Point(174, 233);
            this.comboBoxCursorMode.Name = "comboBoxCursorMode";
            this.comboBoxCursorMode.Size = new System.Drawing.Size(300, 20);
            this.comboBoxCursorMode.TabIndex = 50;
            this.comboBoxCursorMode.SelectedIndexChanged += new System.EventHandler(this.comboBoxCursorMode_SelectedIndexChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(10, 235);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(113, 12);
            this.label15.TabIndex = 49;
            this.label15.Text = "启动时默认光标模式";
            // 
            // checkBoxControlUnhindersCursor
            // 
            this.checkBoxControlUnhindersCursor.AutoSize = true;
            this.checkBoxControlUnhindersCursor.Location = new System.Drawing.Point(11, 172);
            this.checkBoxControlUnhindersCursor.Name = "checkBoxControlUnhindersCursor";
            this.checkBoxControlUnhindersCursor.Size = new System.Drawing.Size(204, 16);
            this.checkBoxControlUnhindersCursor.TabIndex = 48;
            this.checkBoxControlUnhindersCursor.Text = "如果按下此键，允许光标自由移动";
            this.checkBoxControlUnhindersCursor.UseVisualStyleBackColor = true;
            this.checkBoxControlUnhindersCursor.CheckedChanged += new System.EventHandler(this.checkBoxControlUnhindersCursor_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.scrollBarSticky);
            this.groupBox4.Location = new System.Drawing.Point(3, 122);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(477, 40);
            this.groupBox4.TabIndex = 47;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "黏性控制";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(444, 15);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 12);
            this.label13.TabIndex = 41;
            this.label13.Text = "最大";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(237, 15);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 12);
            this.label11.TabIndex = 40;
            this.label11.Text = "最小";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 15);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 12);
            this.label5.TabIndex = 39;
            this.label5.Text = "屏幕之间的移动阻力";
            // 
            // scrollBarSticky
            // 
            this.scrollBarSticky.Location = new System.Drawing.Point(264, 13);
            this.scrollBarSticky.Maximum = 3000;
            this.scrollBarSticky.Name = "scrollBarSticky";
            this.scrollBarSticky.Size = new System.Drawing.Size(177, 17);
            this.scrollBarSticky.SmallChange = 10;
            this.scrollBarSticky.TabIndex = 38;
            this.scrollBarSticky.Value = 100;
            this.scrollBarSticky.ValueChanged += new System.EventHandler(this.scrollBarSticky_ValueChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.hotKeyPanelLockCursor);
            this.groupBox3.Controls.Add(this.hotKeyPanelStickyCursor);
            this.groupBox3.Controls.Add(this.hotKeyPanelFreeCursor);
            this.groupBox3.Location = new System.Drawing.Point(3, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(477, 110);
            this.groupBox3.TabIndex = 46;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "光标移动热键";
            // 
            // hotKeyPanelLockCursor
            // 
            this.hotKeyPanelLockCursor.Description = "描述";
            this.hotKeyPanelLockCursor.Location = new System.Drawing.Point(8, 71);
            this.hotKeyPanelLockCursor.Name = "hotKeyPanelLockCursor";
            this.hotKeyPanelLockCursor.Size = new System.Drawing.Size(465, 21);
            this.hotKeyPanelLockCursor.TabIndex = 2;
            // 
            // hotKeyPanelStickyCursor
            // 
            this.hotKeyPanelStickyCursor.Description = "描述";
            this.hotKeyPanelStickyCursor.Location = new System.Drawing.Point(8, 44);
            this.hotKeyPanelStickyCursor.Name = "hotKeyPanelStickyCursor";
            this.hotKeyPanelStickyCursor.Size = new System.Drawing.Size(465, 21);
            this.hotKeyPanelStickyCursor.TabIndex = 1;
            // 
            // hotKeyPanelFreeCursor
            // 
            this.hotKeyPanelFreeCursor.Description = "描述";
            this.hotKeyPanelFreeCursor.Location = new System.Drawing.Point(8, 18);
            this.hotKeyPanelFreeCursor.Name = "hotKeyPanelFreeCursor";
            this.hotKeyPanelFreeCursor.Size = new System.Drawing.Size(465, 21);
            this.hotKeyPanelFreeCursor.TabIndex = 0;
            // 
            // checkBoxAllowButton
            // 
            this.checkBoxAllowButton.AutoSize = true;
            this.checkBoxAllowButton.Location = new System.Drawing.Point(11, 193);
            this.checkBoxAllowButton.Name = "checkBoxAllowButton";
            this.checkBoxAllowButton.Size = new System.Drawing.Size(216, 16);
            this.checkBoxAllowButton.TabIndex = 53;
            this.checkBoxAllowButton.Text = "如果按下此按键，允许光标自由移动";
            this.checkBoxAllowButton.UseVisualStyleBackColor = true;
            this.checkBoxAllowButton.CheckedChanged += new System.EventHandler(this.checkBoxAllowButton_CheckedChanged);
            // 
            // comboBoxFreeMovementButton
            // 
            this.comboBoxFreeMovementButton.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxFreeMovementButton.FormattingEnabled = true;
            this.comboBoxFreeMovementButton.Location = new System.Drawing.Point(279, 191);
            this.comboBoxFreeMovementButton.Name = "comboBoxFreeMovementButton";
            this.comboBoxFreeMovementButton.Size = new System.Drawing.Size(194, 20);
            this.comboBoxFreeMovementButton.TabIndex = 54;
            this.comboBoxFreeMovementButton.SelectedIndexChanged += new System.EventHandler(this.comboBoxFreeMovementButton_SelectedIndexChanged);
            // 
            // CursorStickyOptionsPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.comboBoxFreeMovementButton);
            this.Controls.Add(this.checkBoxAllowButton);
            this.Controls.Add(this.comboBoxFreeMovementKey);
            this.Controls.Add(this.checkBoxPrimaryReturnUnhindered);
            this.Controls.Add(this.comboBoxCursorMode);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.checkBoxControlUnhindersCursor);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Name = "CursorStickyOptionsPanel";
            this.Size = new System.Drawing.Size(500, 332);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.ComboBox comboBoxFreeMovementKey;
		private System.Windows.Forms.CheckBox checkBoxPrimaryReturnUnhindered;
		private System.Windows.Forms.ComboBox comboBoxCursorMode;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.CheckBox checkBoxControlUnhindersCursor;
		private System.Windows.Forms.GroupBox groupBox4;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.HScrollBar scrollBarSticky;
		private System.Windows.Forms.GroupBox groupBox3;
		private Library.HotKeys.HotKeyPanel hotKeyPanelLockCursor;
		private Library.HotKeys.HotKeyPanel hotKeyPanelStickyCursor;
		private Library.HotKeys.HotKeyPanel hotKeyPanelFreeCursor;
		private System.Windows.Forms.CheckBox checkBoxAllowButton;
		private System.Windows.Forms.ComboBox comboBoxFreeMovementButton;

	}
}
