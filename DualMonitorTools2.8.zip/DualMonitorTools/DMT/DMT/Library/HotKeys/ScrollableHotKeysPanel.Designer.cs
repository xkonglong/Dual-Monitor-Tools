﻿namespace DMT.Library.HotKeys
{
	partial class ScrollableHotKeysPanel
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.hotKeyPanel0 = new DMT.Library.HotKeys.HotKeyPanel();
			this.hotKeyPanel1 = new DMT.Library.HotKeys.HotKeyPanel();
			this.hotKeyPanel2 = new DMT.Library.HotKeys.HotKeyPanel();
			this.hotKeyPanel3 = new DMT.Library.HotKeys.HotKeyPanel();
			this.hotKeyPanel4 = new DMT.Library.HotKeys.HotKeyPanel();
			this.hotKeyPanel5 = new DMT.Library.HotKeys.HotKeyPanel();
			this.hotKeyPanel6 = new DMT.Library.HotKeys.HotKeyPanel();
			this.hotKeyPanel7 = new DMT.Library.HotKeys.HotKeyPanel();
			this.hotKeyPanel8 = new DMT.Library.HotKeys.HotKeyPanel();
			this.hotKeyPanel9 = new DMT.Library.HotKeys.HotKeyPanel();
			this.vScrollBar = new System.Windows.Forms.VScrollBar();
			this.SuspendLayout();
			// 
			// hotKeyPanel0
			// 
			this.hotKeyPanel0.Description = "描述";
			this.hotKeyPanel0.Location = new System.Drawing.Point(0, 0);
			this.hotKeyPanel0.Name = "hotKeyPanel0";
			this.hotKeyPanel0.Size = new System.Drawing.Size(465, 23);
			this.hotKeyPanel0.TabIndex = 0;
			// 
			// hotKeyPanel1
			// 
			this.hotKeyPanel1.Description = "描述";
			this.hotKeyPanel1.Location = new System.Drawing.Point(0, 29);
			this.hotKeyPanel1.Name = "hotKeyPanel1";
			this.hotKeyPanel1.Size = new System.Drawing.Size(465, 23);
			this.hotKeyPanel1.TabIndex = 1;
			// 
			// hotKeyPanel2
			// 
			this.hotKeyPanel2.Description = "描述";
			this.hotKeyPanel2.Location = new System.Drawing.Point(0, 58);
			this.hotKeyPanel2.Name = "hotKeyPanel2";
			this.hotKeyPanel2.Size = new System.Drawing.Size(465, 23);
			this.hotKeyPanel2.TabIndex = 2;
			// 
			// hotKeyPanel3
			// 
			this.hotKeyPanel3.Description = "描述";
			this.hotKeyPanel3.Location = new System.Drawing.Point(0, 87);
			this.hotKeyPanel3.Name = "hotKeyPanel3";
			this.hotKeyPanel3.Size = new System.Drawing.Size(465, 23);
			this.hotKeyPanel3.TabIndex = 3;
			// 
			// hotKeyPanel4
			// 
			this.hotKeyPanel4.Description = "描述";
			this.hotKeyPanel4.Location = new System.Drawing.Point(0, 116);
			this.hotKeyPanel4.Name = "hotKeyPanel4";
			this.hotKeyPanel4.Size = new System.Drawing.Size(465, 23);
			this.hotKeyPanel4.TabIndex = 4;
			// 
			// hotKeyPanel5
			// 
			this.hotKeyPanel5.Description = "描述";
			this.hotKeyPanel5.Location = new System.Drawing.Point(0, 145);
			this.hotKeyPanel5.Name = "hotKeyPanel5";
			this.hotKeyPanel5.Size = new System.Drawing.Size(465, 23);
			this.hotKeyPanel5.TabIndex = 5;
			// 
			// hotKeyPanel6
			// 
			this.hotKeyPanel6.Description = "描述";
			this.hotKeyPanel6.Location = new System.Drawing.Point(0, 174);
			this.hotKeyPanel6.Name = "hotKeyPanel6";
			this.hotKeyPanel6.Size = new System.Drawing.Size(465, 23);
			this.hotKeyPanel6.TabIndex = 6;
			// 
			// hotKeyPanel7
			// 
			this.hotKeyPanel7.Description = "描述";
			this.hotKeyPanel7.Location = new System.Drawing.Point(0, 203);
			this.hotKeyPanel7.Name = "hotKeyPanel7";
			this.hotKeyPanel7.Size = new System.Drawing.Size(465, 23);
			this.hotKeyPanel7.TabIndex = 7;
			// 
			// hotKeyPanel8
			// 
			this.hotKeyPanel8.Description = "描述";
			this.hotKeyPanel8.Location = new System.Drawing.Point(0, 232);
			this.hotKeyPanel8.Name = "hotKeyPanel8";
			this.hotKeyPanel8.Size = new System.Drawing.Size(465, 23);
			this.hotKeyPanel8.TabIndex = 8;
			// 
			// hotKeyPanel9
			// 
			this.hotKeyPanel9.Description = "描述";
			this.hotKeyPanel9.Location = new System.Drawing.Point(0, 261);
			this.hotKeyPanel9.Name = "hotKeyPanel9";
			this.hotKeyPanel9.Size = new System.Drawing.Size(465, 23);
			this.hotKeyPanel9.TabIndex = 9;
			// 
			// vScrollBar
			// 
			this.vScrollBar.LargeChange = 3;
			this.vScrollBar.Location = new System.Drawing.Point(468, 1);
			this.vScrollBar.Name = "vScrollBar";
			this.vScrollBar.Size = new System.Drawing.Size(17, 283);
			this.vScrollBar.TabIndex = 10;
			this.vScrollBar.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vScrollBar_Scroll);
			// 
			// ScrollableHotKeysPanel
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.vScrollBar);
			this.Controls.Add(this.hotKeyPanel9);
			this.Controls.Add(this.hotKeyPanel8);
			this.Controls.Add(this.hotKeyPanel7);
			this.Controls.Add(this.hotKeyPanel6);
			this.Controls.Add(this.hotKeyPanel5);
			this.Controls.Add(this.hotKeyPanel4);
			this.Controls.Add(this.hotKeyPanel3);
			this.Controls.Add(this.hotKeyPanel2);
			this.Controls.Add(this.hotKeyPanel1);
			this.Controls.Add(this.hotKeyPanel0);
			this.Name = "ScrollableHotKeysPanel";
			this.Size = new System.Drawing.Size(488, 286);
			this.ResumeLayout(false);

		}

		#endregion

		private HotKeyPanel hotKeyPanel0;
		private HotKeyPanel hotKeyPanel1;
		private HotKeyPanel hotKeyPanel2;
		private HotKeyPanel hotKeyPanel3;
		private HotKeyPanel hotKeyPanel4;
		private HotKeyPanel hotKeyPanel5;
		private HotKeyPanel hotKeyPanel6;
		private HotKeyPanel hotKeyPanel7;
		private HotKeyPanel hotKeyPanel8;
		private HotKeyPanel hotKeyPanel9;
		private System.Windows.Forms.VScrollBar vScrollBar;
	}
}
