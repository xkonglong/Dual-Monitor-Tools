﻿#region copyright
// This file is part of Dual Monitor Tools which is a set of tools to assist
// users with multiple monitor setups.
// Copyright (C) 2015 Gerald Evans
// 
// Dual Monitor Tools is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
#endregion

namespace DMT
{
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;

	using DMT.Library.Command;
	using DMT.Library.PInvoke;

	/// <summary>
	/// Runs DMT as a console application.
	/// </summary>
	class ConsoleApplication
	{
		ProgramOptions _programOptions;

		/// <summary>
		/// Initialises a new instance of the <see cref="ConsoleApplication" /> class.
		/// </summary>
		/// <param name="programOptions">Options to use (after being parsed from command line)</param>
		public ConsoleApplication(ProgramOptions programOptions)
		{
			_programOptions = programOptions;
		}

		/// <summary>
		/// Allows the DMT console application to do it's processing
		/// </summary>
		public void Run()
		{
			if (_programOptions.Errors.Count > 0)
			{
				foreach (string error in _programOptions.Errors)
				{
					Console.WriteLine(error);
				}

				ShowUsage();
			}
			else if (_programOptions.ShowUsage)
			{
				ShowUsage();
			}
			else if (_programOptions.ShowVersion)
			{
				ShowVersion();
			}
			else if (_programOptions.CloseGui)
			{
				IntPtr hWnd = NativeMethods.FindWindow(null, "DMT_GUI_WINDOW");

				if (hWnd != IntPtr.Zero)
				{
					NativeMethods.SendMessage(hWnd, NativeMethods.WM_CLOSE, IntPtr.Zero, IntPtr.Zero);
				}
			}
			else
			{
				CommandMessaging commandMessaging = new CommandMessaging();
				foreach (string command in _programOptions.Commands)
				{
					string magicCommand = MakeMagicCommand(command);
					CommandMessaging.EMsgResult msgResult = commandMessaging.SendCommandMessage(magicCommand);

					switch (msgResult)
					{
						case CommandMessaging.EMsgResult.OK:
							// nothing to report
							break;

						case CommandMessaging.EMsgResult.DmtNotFound:
							Console.WriteLine("找不到正在运行的 DMT 版本");
							break;

						case CommandMessaging.EMsgResult.CmdUnknown:
							Console.WriteLine("此命令 \"" + command + "\" 未知");
							break;

						default:
							Console.WriteLine("未知错误来自命令: " + ((int)msgResult).ToString());
							break;
					}
				}
			}
		}

		// make sure that the command starts with "DMT:"
		string MakeMagicCommand(string command)
		{
			string magicCommandPrefix = MagicCommand.MagicCommandPrefix;

			if (command.StartsWith(magicCommandPrefix, StringComparison.OrdinalIgnoreCase))
			{
				return command;
			}
			else
			{
				return magicCommandPrefix + command;
			}
		}

		void ShowUsage()
		{
			Console.WriteLine("");
			Console.WriteLine("语法: DMT [选项] [命令]");
			Console.WriteLine(" 无需任何选项或命令，将 Dual Monitor Tools 作为 GUI 应用程序运行在通知区");
			Console.WriteLine(" 如果指定了命令，则 DMT 必须已经作为 GUI 应用程序运行");
			Console.WriteLine();
			Console.WriteLine("选项:");
			Console.WriteLine("  -?   显示帮助");
			Console.WriteLine("  -v   显示版本");
			Console.WriteLine("  -x   关闭通知区域中运行的 DMT");
			Console.WriteLine();
			Console.WriteLine("命令:");
			Console.WriteLine("  General:Options             显示选项");
			Console.WriteLine("  \"General:ChangePrimary 2\"   指定屏幕2为主屏幕");
			Console.WriteLine("  Cursor:FreeCursor           光标在屏幕之间自由移动");
			Console.WriteLine("  Cursor:StickyCursor         屏幕之间的光标移动黏滞");
			Console.WriteLine("  + 还有更多");
			Console.WriteLine("");
		}

		void ShowVersion()
		{
			System.Reflection.Assembly assembly = System.Reflection.Assembly.GetExecutingAssembly();
			System.Diagnostics.FileVersionInfo fileVersionInfo = System.Diagnostics.FileVersionInfo.GetVersionInfo(assembly.Location);
			string version = fileVersionInfo.ProductVersion;
			Console.WriteLine(string.Format("DMT {0}", version));
		}
	}
}
